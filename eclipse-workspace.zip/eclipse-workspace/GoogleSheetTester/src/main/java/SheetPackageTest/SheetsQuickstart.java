package SheetPackageTest;

// This is SheetsQuickstart. This program is used as a demo to demostrate an update to a fix cell location on a Google sheet
// Todos: Please be sure to update the location of your client_secret.json file & the Googlesheet id before running your program.
// Author: Doan Nguyen
// Date: 5/28/18
import com.google.api.client.auth.oauth2.Credential;


import com.google.api.client.extensions.java6.auth.oauth2.AuthorizationCodeInstalledApp;
import com.google.api.client.extensions.jetty.auth.oauth2.LocalServerReceiver;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeFlow;
import com.google.api.client.googleapis.auth.oauth2.GoogleClientSecrets;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.http.HttpTransport;

import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.json.JsonFactory;
import com.google.api.client.util.Data;
import com.google.api.client.util.store.FileDataStoreFactory;
import com.google.api.services.sheets.v4.SheetsScopes;
import com.google.api.services.sheets.v4.model.*;
import com.google.api.services.sheets.v4.Sheets;


import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.mortbay.jetty.servlet.AbstractSessionManager.Session;

import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;


public class SheetsQuickstart {
	static String id = "ID Not Found";
	static String key = "KEY IS INVALID";
	static String section = "Not Found";
	static String course = "Not Found";
	
    /** Application name. */
    private static final String APPLICATION_NAME =
        "Google Sheets API Java Quickstart";

    /** Directory to store user credentials for this application. */
    private static final java.io.File DATA_STORE_DIR = new java.io.File(
        System.getProperty("user.home"), ".credentials//sheets.googleapis.com-java-quickstart.json");

    /** Global instance of the {@link FileDataStoreFactory}. */
    private static FileDataStoreFactory DATA_STORE_FACTORY;

    /** Global instance of the JSON factory. */
    private static final JsonFactory JSON_FACTORY =
        JacksonFactory.getDefaultInstance();

    /** Global instance of the HTTP transport. */
    private static HttpTransport HTTP_TRANSPORT;

    /** Global instance of the scopes required by this quickstart.
     *
     * If modifying these scopes, delete your previously saved credentials
     * at ~/.credentials/sheets.googleapis.com-java-quickstart.json
     */
    private static final List<String> SCOPES =
        Arrays.asList( SheetsScopes.SPREADSHEETS );

	private static final String SheetsQucikstart = null;

	private static String Id = null;

    static {
        try {
            HTTP_TRANSPORT = GoogleNetHttpTransport.newTrustedTransport();
            DATA_STORE_FACTORY = new FileDataStoreFactory(DATA_STORE_DIR);
        } catch (Throwable t) {
            t.printStackTrace();
            System.exit(1);
        }
    }
    
    public static List<Object> UsedDataKey = new ArrayList<>(); //an object that stores the used keys

    /**
     * Creates an authorized Credential object.
     * @return an authorized Credential object.
     * @throws IOException
     */
    public static Credential authorize() throws IOException {
        // Load client secrets.
        // Todo: Change this text to the location where your client_secret.json resided
        InputStream in = new FileInputStream(""); //<--- your client_secret.json file location
            // SheetsQuickstart.class.getResourceAsStream("/client_secret.json");
        GoogleClientSecrets clientSecrets =
            GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(in));

        // Build flow and trigger user authorization request.
        GoogleAuthorizationCodeFlow flow =
                new GoogleAuthorizationCodeFlow.Builder(
                        HTTP_TRANSPORT, JSON_FACTORY, clientSecrets, SCOPES)
                .setDataStoreFactory(DATA_STORE_FACTORY)
                .setAccessType("offline")
                .build();
        Credential credential = new AuthorizationCodeInstalledApp(
            flow, new LocalServerReceiver()).authorize(""); //<-- your email id here that is linked to google drive
        System.out.println(
                "Credentials saved to " + DATA_STORE_DIR.getAbsolutePath());
        return credential;
    }
   
    /**
     * Build and return an authorized Sheets API client service.
     * @return an authorized Sheets API client service
     * @throws IOException
     */
    public static Sheets getSheetsService() throws IOException {
        Credential credential = authorize();
        if (!credential.refreshToken()) {
            throw new RuntimeException("Failed OAuth to refresh the token");
          }
        return new Sheets.Builder(HTTP_TRANSPORT, JSON_FACTORY, credential)
                .setApplicationName(APPLICATION_NAME)
                .build();
        
    }
    
    
    
    //function to calculate gps
    
    public double distance(double lat1, double lon1, double lat2, double lon2, String sr) {

        double theta = lon1 - lon2;
        double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
        dist = Math.acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        if (sr.equals("K")) {
          dist = dist * 1.609344;
        } else if (sr.equals("N")) {
          dist = dist * 0.8684;
          }
        return (dist);
      }
    
    public double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
      }
    
    public double rad2deg(double rad) {
        return (rad * 180.0 / Math.PI);
      }
    

     
 // A function to get the values from the sheet and then we will rebuilt it
    public static String result(String paramId,String paramKey,String paramClass,String paramSection) throws IOException, GeneralSecurityException {
    String status = "done";	
     Sheets service = getSheetsService();
   	 String spreadsheetId = ""; //<-- spreadsheet ID
   	 String rangeForRow = "A1:Z1"; // TODO: Update placeholder value.
   	 String rangeForAll = "A1:Z"; //using this to get each and every element
   	 String rangeForId = "B1:B10000"; //for only id
   	 String rangeForDateKey = "E1:Z";
   	 
   	 ValueRange response = service.spreadsheets().values().get(spreadsheetId, rangeForRow).execute(); //for only rows
   	 ValueRange responseForAll = service.spreadsheets().values().get(spreadsheetId, rangeForAll).execute(); //for all values
   	 ValueRange responseForId = service.spreadsheets().values().get(spreadsheetId, rangeForId).execute(); //for all Ids
   	 ValueRange responseForDateKey = service.spreadsheets().values().get(spreadsheetId, rangeForDateKey).execute(); //for all particular date and key
   	List<List<Object>> values = response.getValues();
   	List<List<Object>> valuesAll = responseForAll.getValues();
   	List<List<Object>> valuesId = responseForId.getValues();
   	List<List<Object>> valuesDateKey = responseForDateKey.getValues();
   	List<Request> requests = new ArrayList<>();
   	List<CellData> valuesPresent = new ArrayList<>();
   	List<CellData> sectionAdd = new ArrayList<>();
   	List<CellData> classAdd = new ArrayList<>();
 
   	
    if (values == null || values.isEmpty()) {
        System.out.println("No data found.");

    	//code that works for both randomid and date
    } else {
    	
            // Print columns A and E, which correspond to indices 0 and 4.
    		int count = 0,rowCount = 0;
    		List<Object> DateKey = new ArrayList<>(); // a local variable to store todays random id and date
    		
    		int len = valuesAll.size(); //this will store the length of all values and in particular for loop it only stores the values of corresponding column
    		//to get the particular date on that day
    		String pattern = "MM/d/YYYY";
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

			String date = simpleDateFormat.format(new Date()); 	
    		
    		
	
    		//to get the index of last row
    			for(List row: values) {
    				//got index of last column by using below
    				rowCount = row.size();
    				//for loop for getting the count of columns its tricky because we used list as data type
    				for(int i=rowCount;i<rowCount+1;i++) {
    					
    					//System.out.println(rowCount);
    					 //getting the last inserted row  
        				//System.out.println(i-1);
        				
        				
        				
        				
        				
        				//System.out.println(len); //getting length of one particular index
        				//for loop to get the rows again tricky as values is a variable which is assigned from response which again gives total rows
        				for(int j=len;j<len+1;j++) {
        					
        					
        					
        					
        					
        					
        					
        					//to get the student id data
            				for(int k=0;k<valuesId.size();k++) {
            					//System.out.println(valuesId.get(k));
            				
        					
        					
        					
        				DateKey.add(valuesAll.get(len-1)); //even though we are adding columns to it. its of no use since we are using valuesAll.get(j-1).contains("random id")
        				DateKey.add(row.get(i-1)); //most crucial step as row.get(i) doesn't support contains method
        					//System.out.println(valuesAll.get(j-1));
        					//System.out.println(DateKey);
        				//System.out.println(paramId);
        			    //System.out.println(paramKey);
        					//System.out.println(valuesAll.get(j-1)); //flag lives here
        					//System.out.println(valuesAll.get(j-2)); //key exists here
        					List<Object> param = new ArrayList<>();
    						param.add(paramId);
    						List<Object> Section = new ArrayList<>(); // a local variable to store section
    			    		List<Object> Class = new ArrayList<>(); // a local variable to store class
    			    		Section.add(paramSection);
    			    		Class.add(paramClass);
        					if(valuesAll.get(j-1).contains(paramKey) && DateKey.contains(date) && valuesId.get(k).contains(paramId)) {
        						//System.out.println(valuesId.indexOf(param)); //get the index of student id
        						//to get the index of row
        						int rowIndex = valuesId.indexOf(param);
        						//System.out.println(rowIndex);
        						//System.out.println(i-1);
        						
        						//System.out.println("value found");
        						//after finding value insert present for the corresponding day
        						//adding "yes" in regarding to the id
        						valuesPresent.add(new CellData()
        				                 .setUserEnteredValue(new ExtendedValue()
        				                         .setStringValue(("Yes"))));
        						requests.add(new Request()
                                        .setUpdateCells(new UpdateCellsRequest()
                                                .setStart(new GridCoordinate()
                                                        .setSheetId(0)
                                                        .setRowIndex(rowIndex)     // set the row to row 2 
                                                        .setColumnIndex(i-1)) // set the new column 6 to value "abc" at row 1
                                                .setRows(Arrays.asList(
                                                        new RowData().setValues(valuesPresent)))
                                                .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
        						 
        						   BatchUpdateSpreadsheetRequest batchUpdateRequestPresent = new BatchUpdateSpreadsheetRequest()
                                	        .setRequests(requests);
                                	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestPresent)
                                	        .execute();
                                	//adding section to the sheet for desired id
                                	sectionAdd.add(new CellData()
           				                 .setUserEnteredValue(new ExtendedValue().setStringValue(paramSection)));
                                	requests.add(new Request().setUpdateCells(new UpdateCellsRequest().setStart(new GridCoordinate().setSheetId(0).setRowIndex(rowIndex).setColumnIndex(i-2)).setRows(Arrays.asList(new RowData().setValues(sectionAdd))).setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
                                	
                                	 BatchUpdateSpreadsheetRequest batchUpdateRequestSection = new BatchUpdateSpreadsheetRequest().setRequests(requests);
                                	 service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestSection).execute();
                                //adding class to the sheet for desired id
                                	 classAdd.add(new CellData()
               				                 .setUserEnteredValue(new ExtendedValue().setStringValue(paramClass)));
                                	 
                                	 requests.add(new Request().setUpdateCells(new UpdateCellsRequest().setStart(new GridCoordinate().setSheetId(0).setRowIndex(rowIndex).setColumnIndex(i-3)).setRows(Arrays.asList(new RowData().setValues(classAdd))).setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
                                	 BatchUpdateSpreadsheetRequest batchUpdateRequestClass = new BatchUpdateSpreadsheetRequest().setRequests(requests);
                                	 service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestClass).execute();
        						
        						//end of inserting data
        						//DateKey.remove(j-1);
        						//System.out.println(valuesId.get(8));

        						
        						
        						
        					} else {
        						System.out.println("key or id error");
        					}
        					
            				}
        					//end of student data acquisition
        				}
        			}
    				
    				
    			}
    			
    			//code to get particular index values for date and key
    				
         
           	 
    				
    			
   
    				
    			    //System.out.println(valuesDateKey.get(0) + " " + valuesDateKey.get(87));
    			    // List<Object> demo = new ArrayList<>();
    			     //demo.add(valuesDateKey.get(0));
    			     //demo.add(valuesDateKey.get(87));
    			     //System.out.println(demo);
    			
    			//System.out.println(DateKey);
    			
                    		
                
    			
    			
    			
    			
    			//to work with index of last row
    			//System.out.println(rowCount);
    			/*for (List row : values) {
    				System.out.printf("%s\n", row.get(0));
    			}*/
    	
    }
 
    return paramKey;
    }
    
    
    
    
    
   //working teacher code to insert key and date in a new sheet
    public static String fRandomKey(String totalCreateTime) throws IOException, GeneralSecurityException {
    	
    	Sheets service = getSheetsService();
   	    String spreadsheetId = ""; //<-- spreadsheet id
   	    final String range = "Sheet2!A1:Z";
   	    final String rangeForSheet1 = "Sheet1!A1:Z1";
     ValueRange response = service.spreadsheets().values()
             .get(spreadsheetId, range)
             .execute();
     ValueRange responseForSheet1 = service.spreadsheets().values()
             .get(spreadsheetId, rangeForSheet1)
             .execute();
     //generate date that is todays
	    String pattern = "MM/d/YYYY";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String date = simpleDateFormat.format(new Date());
		String key = "";
		
 	List<CellData> valuesKey = new ArrayList<>(); //stores date
 	List<CellData> latitudeCell = new ArrayList<>(); // store latitude
 	List<CellData> longitudeCell = new ArrayList<>();
 	
 	
 	valuesKey.add(new CellData().setUserEnteredValue(new ExtendedValue().setStringValue(date.toString())));
	    List<List<Object>> values = response.getValues();
	    List<List<Object>> valuesOfSheet1 = responseForSheet1.getValues();
	    List<Request> requests = new ArrayList<>();
     
     
     if (values == null || values.isEmpty()) {
         System.out.println("No data found.");
     } else {
         for (List row : values) {
        	 int len = row.size();
        	 for(int i=len;i<len+1;i++) {
        		 
        		 
        		 
        		 
        		 
        		 
        		 
        		 //adding date to sheet 2
        		 requests.add(new Request()
                         .setUpdateCells(new UpdateCellsRequest()
                                 .setStart(new GridCoordinate()
                                         .setSheetId(995359112)
                                         .setRowIndex(0)    
                                         .setColumnIndex(i)) 
                                 .setRows(Arrays.asList(
                                         new RowData().setValues(valuesKey)))
                                 .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
          	   BatchUpdateSpreadsheetRequest batchUpdateRequestKey = new BatchUpdateSpreadsheetRequest()
              	        .setRequests(requests);
              	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestKey)
              	        .execute();
              	
              	
              	
              	
              	
              	//adding random key
              	SecureRandom random = new SecureRandom();
              	int randid = random.nextInt(100000);
            	while(randid<10000){
            		randid = random.nextInt(100000);
            	}
            	String formatted = 	String.format("%5d",randid);
            	key = formatted;
            	List<CellData> valuesRand = new ArrayList<>();
            	valuesRand.add(new CellData().setUserEnteredValue(new ExtendedValue().setStringValue(formatted)));
              	 requests.add(new Request()
                         .setUpdateCells(new UpdateCellsRequest()
                                 .setStart(new GridCoordinate()
                                         .setSheetId(995359112)
                                         .setRowIndex(1)     // set the row to row 2 
                                         .setColumnIndex(i)) // set the new column 6 to value "abc" at row 1
                                 .setRows(Arrays.asList(
                                         new RowData().setValues(valuesRand)))
                                 .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
          	   BatchUpdateSpreadsheetRequest batchUpdateRequestRand = new BatchUpdateSpreadsheetRequest()
              	        .setRequests(requests);
              	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestRand)
              	        .execute();
              	
              	
              	//adding session time to sheet 2
              	
              	List<CellData> valuesSession = new ArrayList<>();
              	valuesSession.add(new CellData().setUserEnteredValue(new ExtendedValue().setStringValue(totalCreateTime)));
              	requests.add(new Request()
                        .setUpdateCells(new UpdateCellsRequest()
                                .setStart(new GridCoordinate()
                                        .setSheetId(995359112)
                                        .setRowIndex(2)     // set the row to row 3 
                                        .setColumnIndex(i)) 
                                .setRows(Arrays.asList(
                                        new RowData().setValues(valuesSession)))
                                .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
         	   BatchUpdateSpreadsheetRequest batchUpdateRequestSession = new BatchUpdateSpreadsheetRequest()
             	        .setRequests(requests);
             	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestSession)
             	        .execute();
             	
             	//adding latitude and longitude to sheet 2
       		 
       		
              	
              	
              	
              	//adding date to sheet one
              	for (List row1 : valuesOfSheet1) {
               	 int len1 = row1.size();
               	 for(int j=len1;i<len1+1;i++) {
               		 //adding date
               		 requests.add(new Request()
                                .setUpdateCells(new UpdateCellsRequest()
                                        .setStart(new GridCoordinate()
                                                .setSheetId(0)
                                                .setRowIndex(0)    
                                                .setColumnIndex(j)) 
                                        .setRows(Arrays.asList(
                                                new RowData().setValues(valuesKey)))
                                        .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
                 	   BatchUpdateSpreadsheetRequest batchUpdateRequestDateSheet1 = new BatchUpdateSpreadsheetRequest()
                     	        .setRequests(requests);
                     	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestDateSheet1)
                     	        .execute();
               	 }
              	}
              	
        		 
        	 }
    	 
         }
     }

    	return key + totalCreateTime;
    	
    }
    
    // code to check student date and key
    
    public static String [] bresult(String paramId,String paramKey,String paramClass,String paramSection) throws IOException, GeneralSecurityException {
    	Sheets service = getSheetsService();
    
    	
    	 String spreadsheetId = ""; //<-- spreadsheet id
    	
    	String ar[] = new String[5];
   	    //ValueRange responseForlatlong = service.spreadsheets().values().get(spreadsheetId, latlong).execute();
   	 //List<List<Object>> valueslatlong = responseForlatlong.getValues();
   //	String latteacher = valueslatlong.get(0).get(0).toString();
	    
    	String paramId1 = paramId;
    	
   	  
   	
    	
    	    ar[0] = "Invalid Data";
		    ar[1] = "Invalid Data";
	    	ar[2] = "Invalid Data";
	    	ar[3] = "Invalid Data";
    	String er = "";
 
    	
   	   
   	    final String rangeSheet3 = "Sheet3!A1:Z"; //whole purpose is to save id date and time in sheet 3 to check if time reached 0 
   	    final String rangeSheet2 = "Sheet2!A1:Z";
   	    final String rangeSheet1 = "Sheet1!A1:Z1"; //using this range to get header size
   	     
   	    String rangeForId = "B1:B10000"; //for only id
   	   ValueRange responseForId = service.spreadsheets().values().get(spreadsheetId, rangeForId).execute(); //for all Ids
   	ValueRange responseForSheet3 = service.spreadsheets().values().get(spreadsheetId, rangeSheet3).execute();
   	    List<List<Object>> valuesId = responseForId.getValues(); //getting ids
   	    int rowCount = 0;
   	    int rowCountDateKey = 0;
   	    //to get the particular date on that day
		String pattern = "MM/d/YYYY";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		String date = simpleDateFormat.format(new Date());
		List<CellData> valueDate = new ArrayList<>(); // a cell value to hold and insert date;
		List<Request> requests = new ArrayList<>();
		List<Object> param = new ArrayList<>();
		param.add(paramId);
		List<Object> Section = new ArrayList<>(); // a local variable to store section
		List<Object> Class = new ArrayList<>(); // a local variable to store class
		List<CellData> valuesPresent = new ArrayList<>(); // a variable to store yes
		Section.add(paramSection);
		List<CellData> sectionAdd = new ArrayList<>();
		Class.add(paramClass);
		List<CellData> classAdd = new ArrayList<>();
		int counter = 0;
   	    //List<Object> time = new ArrayList<>();
   	 ValueRange response = service.spreadsheets().values()
             .get(spreadsheetId, rangeSheet1)
             .execute();
   	ValueRange responseForDateKey = service.spreadsheets().values()
            .get(spreadsheetId, rangeSheet2)
            .execute();
   	//ValueRange responseForTime = service.spreadsheets().values().get(spreadsheetId, rangeSheet3).execute(); //for saving time in sheet 3
     List<List<Object>> valuesOfSheet3 = responseForSheet3.getValues(); //holds values of sheet 1
     List<List<Object>> values = response.getValues(); //holds values of sheet 1
     List<List<Object>> valuesOfDateKey = responseForDateKey.getValues(); //holds values of sheet 2
    // List<List<Object>> valuesOfTime = responseForTime.getValues(); //holds values of sheet 3
     List<Object> DateKey = new ArrayList<>();
     List<Object> DateId = new ArrayList<>();
     //time.add(paramTime);
     //List<CellData> valuesTime = new ArrayList<>(); //sheet 3
     //List<CellData> valueid = new ArrayList<>(); //sheet 3
     //valuesTime.add(new CellData().setUserEnteredValue(new ExtendedValue().setStringValue(paramTime)));//time
     //valueid.add(new CellData().setUserEnteredValue(new ExtendedValue().setStringValue(paramId)));//id
     //date
   //generate date that is todays
	   // String pattern1 = "MM/d/YYYY";
		//SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);

		//String date1 = simpleDateFormat1.format(new Date());	
	//List<CellData> valuesDate = new ArrayList<>(); //stores date for sheet 3
	
	//valuesDate.add(new CellData().setUserEnteredValue(new ExtendedValue().setStringValue(date.toString()))); //for sheet 3
     int sizeofRow3=0;
     if(valuesOfSheet3 == null || valuesOfSheet3.isEmpty()) {
    	 System.out.println("no data found");
     } else {
    	 for(List row3:valuesOfSheet3) {
    		 //System.out.println(row3.get(0) + " " + row3.get(1));
    		 DateId.add(row3.get(0));
    		 DateId.add(row3.get(1));
    	 }
    	 System.out.println(DateId);
    	 
     }
     
     
     
     if (values == null || values.isEmpty()) {
         System.out.println("No data found.");
     } else {
        
         for(List row1:valuesOfDateKey) {
        	//get the count of number of heading on sheet2 A1:Z
        	 rowCountDateKey = row1.size()-1;
        	 DateKey.add(row1.get(rowCountDateKey));
        	 }
         System.out.println(DateKey);
         
         
       //a for loop to store the id date and time
         /*
         
         //id
         requests.add(new Request()
                 .setUpdateCells(new UpdateCellsRequest()
                         .setStart(new GridCoordinate()
                                 .setSheetId(385963512)
                                 .setRowIndex(0)    
                                 .setColumnIndex(1)) 
                         .setRows(Arrays.asList(
                                 new RowData().setValues(valueid))) //for storing id in sheet 3
                         .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
  	   BatchUpdateSpreadsheetRequest batchUpdateRequestIdSheet3 = new BatchUpdateSpreadsheetRequest()
      	        .setRequests(requests);
      	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestIdSheet3)
      	        .execute();
         //time
         requests.add(new Request()
                 .setUpdateCells(new UpdateCellsRequest()
                         .setStart(new GridCoordinate()
                                 .setSheetId(385963512)
                                 .setRowIndex(1)    
                                 .setColumnIndex(1)) 
                         .setRows(Arrays.asList(
                                 new RowData().setValues(valuesTime)))
                         .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
  	   BatchUpdateSpreadsheetRequest batchUpdateRequestTime = new BatchUpdateSpreadsheetRequest()
      	        .setRequests(requests);
      	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestTime)
      	        .execute();
         //date
         
      	requests.add(new Request()
                .setUpdateCells(new UpdateCellsRequest()
                        .setStart(new GridCoordinate()
                                .setSheetId(385963512)
                                .setRowIndex(2)    
                                .setColumnIndex(1)) 
                        .setRows(Arrays.asList(
                                new RowData().setValues(valuesDate)))
                        .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
 	   BatchUpdateSpreadsheetRequest batchUpdateRequestDate = new BatchUpdateSpreadsheetRequest()
     	        .setRequests(requests);
     	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestDate)
     	        .execute();
      	
      	*/
        
          
         
         for (List row : values) {
             // get a count of number of headings
        	 rowCount = row.size();
        	// System.out.println(rowCount);
        	 for(int i=rowCount;i<rowCount+1;i++) {
        		 //System.out.println(i);
        		 for(int k=0;k<valuesId.size();k++) {
        			// System.out.println(k);
        			 int rowIndex = valuesId.indexOf(param);
        			 System.out.println(DateId.get(0));
        			   String pattern1 = "MM/d/YYYY";
        				SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat(pattern1);
        				String date1 = simpleDateFormat1.format(new Date());
        				ar[4] = "attendance can be marked";
        			 if(DateId.contains(paramId1) && DateId.contains(date1)) {
        				 System.out.println("already marked");
        				 ar[4] = "attendance already marked";
        			 } else {
        				 //if not already marked
        				 if(DateKey.contains(paramKey) && DateKey.contains(date) && valuesId.get(k).contains(paramId) ) {     				 
            				 List <Object> count = new ArrayList<>();
            				 //count.add(valuesId.get(k));
            				 //count.add(counter);
            				 //System.out.println(count);
            				
            				 	errorCheck(valuesId.get(k).toString(),date);
            					valuesPresent.add(new CellData()
       				                 .setUserEnteredValue(new ExtendedValue()
       				                         .setStringValue(("Yes"))));
       						requests.add(new Request()
                                       .setUpdateCells(new UpdateCellsRequest()
                                               .setStart(new GridCoordinate()
                                                       .setSheetId(0)
                                                       .setRowIndex(rowIndex)     // set the row to row 2 
                                                       .setColumnIndex(i-1)) // set the new column 6 to value "abc" at row 1
                                               .setRows(Arrays.asList(
                                                       new RowData().setValues(valuesPresent)))
                                               .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
       						//System.out.println(valuesId.get(rowIndex));
       						
       					  BatchUpdateSpreadsheetRequest batchUpdateRequestPresent = new BatchUpdateSpreadsheetRequest()
                      	        .setRequests(requests);
                      	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestPresent)
                      	        .execute();
                      
                      	
                      	
                      //adding section to the sheet for desired id
                    	sectionAdd.add(new CellData()
    			                 .setUserEnteredValue(new ExtendedValue().setStringValue(paramSection)));
                    	requests.add(new Request().setUpdateCells(new UpdateCellsRequest().setStart(new GridCoordinate().setSheetId(0).setRowIndex(rowIndex).setColumnIndex(3)).setRows(Arrays.asList(new RowData().setValues(sectionAdd))).setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
                    	
                    	 BatchUpdateSpreadsheetRequest batchUpdateRequestSection = new BatchUpdateSpreadsheetRequest().setRequests(requests);
                    	 service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestSection).execute();
                    	//adding class to the sheet for desired id
                    	 classAdd.add(new CellData()
    				                 .setUserEnteredValue(new ExtendedValue().setStringValue(paramClass)));
                    	 
                    	 requests.add(new Request().setUpdateCells(new UpdateCellsRequest().setStart(new GridCoordinate().setSheetId(0).setRowIndex(rowIndex).setColumnIndex(2)).setRows(Arrays.asList(new RowData().setValues(classAdd))).setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
                    	 BatchUpdateSpreadsheetRequest batchUpdateRequestClass = new BatchUpdateSpreadsheetRequest().setRequests(requests);
                    	 service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestClass).execute();	
                      	
                    	 id = paramId;
                    	 key = paramKey;
        				 section = paramSection;
        				 course = paramClass;
        				    ar[0] = id;
        			    	ar[1] = key;
        			    	ar[2] = section;
        			    	ar[3] = course;
        				
        				 
            			 } else {
            				 System.out.println("key or id error");
            			 }
        			 }
        			
        			 
        			

        		 }
        		 
        		 
        	 }
         }
         
         
         
         
         
         
       
        
         //System.out.println(rowCountDateKey); //print the count of number of heading on sheet2 A1:Z
         
         
         
        // System.out.println(rowCount); //count of number of heading on A1:Z1
        
         
     }
    	
    	
    	
    	return ar;//"id = " + id + "key = " + key + "section = " +  section + "course = " + course;
    }
    // a function to get the session time from the sheet  
   public static Object sessiontime() throws IOException, GeneralSecurityException{
	   Sheets service = getSheetsService();
  	    String spreadsheetId = ""; //<-- spreadsheet id
  	    final String range = "Sheet2!A1:Z";
  	  ValueRange response = service.spreadsheets().values()
              .get(spreadsheetId, range)
              .execute();
  	int len = 0;
  	Object s="";
     	List<List<Object>> values = response.getValues();
  	if (values == null || values.isEmpty()) {
        System.out.println("No data found.");
    } else {
        for (List row : values) {
       	len = row.size();
       	s = row.get(len-1);
        }
    }
	   return s;
   }
  
   
   public static Object errorCheck(String paramId,String date) throws IOException, GeneralSecurityException{
	   Sheets service = getSheetsService();
	   String spreadsheetId = ""; //<-- spreadsheet id
	   final String range = "Sheet3!A1:Z";
	   int len = 0;
	   int rowIndex = 0;
	   ValueRange response = service.spreadsheets().values()
	              .get(spreadsheetId, range)
	              .execute();
	   List<List<Object>> values = response.getValues();
	   List<Request> requests = new ArrayList<>();
	   List<Request> requests1 = new ArrayList<>();
	   //generate date that is todays
	    String pattern = "MM/d/YYYY";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

		String date1 = simpleDateFormat.format(new Date());
		String key = "";
		
	List<CellData> valuesKey = new ArrayList<>(); //stores date
	List<CellData> valuesId = new ArrayList<>(); //stores id
	valuesKey.add(new CellData().setUserEnteredValue(new ExtendedValue().setStringValue(date1.toString())));
	valuesId.add(new CellData().setUserEnteredValue(new ExtendedValue().setStringValue(paramId)));
	  	if (values == null || values.isEmpty()) {
	        System.out.println("No data found.");
	    } else {
	        for (List row : values) {
	       	len = row.size();
	    	rowIndex = len;
	        }
	       	int rows = values.size();
	       		requests.add(new Request()
                        .setUpdateCells(new UpdateCellsRequest()
                                .setStart(new GridCoordinate()
                                        .setSheetId(385963512)
                                        .setRowIndex(rows)     
                                        .setColumnIndex(0)) 
                                .setRows(Arrays.asList(
                                        new RowData().setValues(valuesKey)))
                                .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
         	   BatchUpdateSpreadsheetRequest batchUpdateRequestDateSheet1 = new BatchUpdateSpreadsheetRequest()
             	        .setRequests(requests);
             	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestDateSheet1)
             	        .execute();
         
	       		requests1.add(new Request()
                        .setUpdateCells(new UpdateCellsRequest()
                                .setStart(new GridCoordinate()
                                        .setSheetId(385963512)
                                        .setRowIndex(rows)     
                                        .setColumnIndex(1)) 
                                .setRows(Arrays.asList(
                                        new RowData().setValues(valuesId)))
                                .setFields("userEnteredValue,userEnteredFormat.backgroundColor")));
         	   BatchUpdateSpreadsheetRequest batchUpdateRequestDateSheet2 = new BatchUpdateSpreadsheetRequest()
             	        .setRequests(requests1);
             	service.spreadsheets().batchUpdate(spreadsheetId, batchUpdateRequestDateSheet2)
             	        .execute();
	   
	   
   }
	  	return "";
   }
   
   
    
}
