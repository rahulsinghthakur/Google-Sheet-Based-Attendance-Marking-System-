package net.codejava.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.Date;
import SheetPackageTest.SheetsQuickstart;
public class Teacher extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		String paramUname = request.getParameter("uname");
		String uname = new String(paramUname); 
		String paramPwd = request.getParameter("pwd");
		String pwd = new String(paramPwd);
		String paramSection = request.getParameter("section");
		String section = new String(paramSection);
		
		
		
		//Random random = new Random();
		//String randid = String.format("%04d", random.nextInt(10000));
		
		if(uname.equals("rahul") && pwd.equals("rahul")) {
			PrintWriter writer = response.getWriter();
			writer.println("Welcome, " + uname);
			writer.println(uname + " " +  pwd + " " + section);
			request.setAttribute("username", uname);

			try {
				//writer.print(SheetsQuickstart.drandomKey());
				//writer.println(SheetsQuickstart.fRandomKey());
				HttpSession session = request.getSession(true);
				session.invalidate();
				session = request.getSession(true);
				Date createTime = new Date(session.getCreationTime());
				 SimpleDateFormat dd = new SimpleDateFormat("mm"); //for minutes
				   SimpleDateFormat HH = new SimpleDateFormat("HH"); //for hours
				   String s = dd.format(createTime);
				   String H = HH.format(createTime); 
				   String totalCreateTime = H+s;	//gives a string value   
				   //int creationtime = Integer.parseInt(s);
				   //int TotalCreateTime = Integer.parseInt(totalCreateTime);
					//System.out.println(TotalCreateTime);
					session.getId();
					//writer.println(SheetsQuickstart.fRandomKey(totalCreateTime));
					String keytime = SheetsQuickstart.fRandomKey(totalCreateTime);
				
					char[] t = keytime.toCharArray();
					
					String newKey =String.valueOf(t[0]);
					String newKey1 =String.valueOf(t[1]);
					String newKey2 =String.valueOf(t[2]);
					String newKey3 =String.valueOf(t[3]);
					String newKey4 =String.valueOf(t[4]);
					System.out.println(newKey);
					System.out.println(newKey1);
					String total = newKey + newKey1 + newKey2 + newKey3 + newKey4;
					System.out.println(total);
					request.setAttribute("key", total);
					request.setAttribute("section", section);
					//System.out.println(new Date(session.getCreationTime()));
					request.getRequestDispatcher("/ackT.jsp").forward(request, response);
				
			} catch (GeneralSecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			writer.flush();
			
		} else {
			PrintWriter writer = response.getWriter();
			writer.println("username/password invalid");
		}
		
		

		
	}
	
	

	
	
 
}
