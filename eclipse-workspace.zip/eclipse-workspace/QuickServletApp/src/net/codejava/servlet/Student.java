package net.codejava.servlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.GeneralSecurityException;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import SheetPackageTest.SheetsQuickstart;
public class Student extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException {
		String paramUname = request.getParameter("uname");
		String uname = new String(paramUname); 
		String paramPwd = request.getParameter("pwd");
		String pwd = new String(paramPwd);
		String paramSection = request.getParameter("section");
		String section = new String(paramSection);
		if(uname.equals("rahul") && pwd.equals("rahul")) {
			PrintWriter writer = response.getWriter();
			writer.println("Welcome, " + uname);
			writer.println(uname + " " +  pwd + " " + section);
			writer.flush();
			
		} else {
			PrintWriter writer = response.getWriter();
			writer.println("username password mismatch");
		}
	}
	
}