package net.codejava.servlet;

import java.io.IOException;

import java.io.PrintWriter;
import java.security.GeneralSecurityException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionListener;

import com.google.api.client.googleapis.json.GoogleJsonError;
import com.google.api.client.googleapis.json.GoogleJsonResponseException;

import SheetPackageTest.SheetsQuickstart;
public class QuickServlet extends HttpServlet implements HttpSessionListener{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * this life-cycle method is invoked when this servlet is first accessed
	 * by the client
	 */
	public void init(ServletConfig config) {
		System.out.println("Servlet is being initialized");
	}

	/**
	 * handles HTTP GET request
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException {

		PrintWriter writer = response.getWriter();
	
		  
		  
		  
		  writer.println("<html>Hello, I am a Java servlet!</html>");
		  writer.flush();
	}

	/**
	 * handles HTTP POST request
	 * @throws ServletException 
	 */
	
	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException, ServletException {
		int counter = 0;
		
		
		String paramKey = request.getParameter("key");
		//int key = Integer.parseInt(paramKey);

		String paramId = request.getParameter("id");
		//int id = Integer.parseInt(paramId);
		
		String paramClass = request.getParameter("class");
		
		String paramSection = request.getParameter("section");
		HttpSession session = request.getSession();
		session.setAttribute("count", counter);
		String paramTime = request.getParameter("TotalCreateTime");
		String ParamNowTime = request.getParameter("TotalNowTime");
		int paramNowTime = Integer.parseInt(ParamNowTime);
		int diff = 0;
		//session.setAttribute("time", ParamTime);
		//request.setAttribute("time", ParamTime);
		 try {
			//SheetsQuickstart.updateSheet();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//writer.println("<html>Area of the rectangle is: " + area + "</html>");
		//writer.flush();
		
		try {
			
			//
			
			
			PrintWriter writer = response.getWriter();
			//writer.println(SheetsQuickstart.bresult(paramId,paramKey,paramClass,paramSection));
				//System.out.println(SheetsQuickstart.sessiontime());
				String s = SheetsQuickstart.sessiontime().toString();
				int sessiontime = Integer.parseInt(s);
				System.out.println(sessiontime);
				diff = paramNowTime - sessiontime;
				System.out.println(diff);
				if(diff<1) {
					String pattern = "MM/d/YYYY";
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
					String date = simpleDateFormat.format(new Date());
					counter++;
					session.setAttribute("count", counter);	
					String[] as  =  SheetsQuickstart.bresult( paramId, paramKey, paramClass, paramSection);
					request.setAttribute("id", as[0]);
					request.setAttribute("key", as[1]);
					request.setAttribute("section", as[2]);
					request.setAttribute("course", as[3]);
					
					writer.println(SheetsQuickstart.errorCheck(paramId, date));
					//System.out.println(counter);
					
					//request.setAttribute("flag", as[4]);
					System.out.println(as[0]);
					System.out.println(as[4]);
					if(as[4].equals("attendance already marked")) {
						request.changeSessionId();
						writer.println("Attendance already marked");
					}
					else {
						request.changeSessionId();
					request.getRequestDispatcher("/ack.jsp").forward(request, response);
					}
					
					
					
				} else if(diff>=1) {
					writer.println("Sorry you are late attendence cannot be marked now");
				} else {writer.println("system error");}
		     
			
		} catch (GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	

	/**
	 * this life-cycle method is invoked when the application or the server
	 * is shutting down
	 */
	public void destroy() {
		System.out.println("Servlet is being destroyed");
	}
}